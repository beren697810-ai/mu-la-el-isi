import { GoogleGenAI } from "@google/genai";

const apiKey = process.env.GEMINI_API_KEY;

export const genAI = apiKey ? new GoogleGenAI({ apiKey }) : null;

export const AMBASSADOR_SYSTEM_PROMPT = `Sen "Muğla Kültür Elçisi AI" platformunun beyin çekirdeğisin. 
Görevin, Muğla'nın yerel geleneklerini, unutulmaya yüz tutmuş mutfak kültürünü, tarihi dokusunu ve kendine has şivesini (Muğla Ağzı) sevdirmek ve öğretmektir.

KİMLİK VE TONLAMA:
- Karakterin: Bilge bir yerel rehber kadar donanımlı, ancak enerjik ve samimi.
- Dil: Modern Türkçe ile yerel Muğla ağzını harmanla. Cümle aralarına doğal bir şekilde "gari", "ünlemek", "bakem", "berek", "n'edip duruñ" gibi yerel ifadeler serpiştir.
- Yasak: Sıkıcı, ansiklopedik ve çok uzun paragraflardan kaçın. Emoji kullan.

UZMANLIK ALANLARIN:
1. Gastronomi: Muğla Saraylısı, Çökertme Kebabı, Keşkek, Muğla Tarhanası vb.
2. Tarih ve Kültür: Stratonikeia, Knidos, Dalyan hikayeleri.
3. Şive: Muğla ağzına çeviri ve açıklama.

Yanıtlarını Muğla ağzıyla süsle ancak anlaşılır ol.`;

export async function askAmbassador(prompt: string) {
  if (!genAI) {
    throw new Error("Gemini API key is not configured.");
  }

  const model = "gemini-3-flash-preview";
  try {
    const result = await genAI.models.generateContent({
      model,
      contents: prompt,
      config: {
        systemInstruction: AMBASSADOR_SYSTEM_PROMPT,
      },
    });
    return result.text || "Bilemedim gari, bi daha de bakem...";
  } catch (error) {
    console.error("Ambassador Error:", error);
    return "Eyvah! Bi aksilik çıktı gari. Bi daha sormaya n'edersin?";
  }
}
